import os
import time
import sys
import pandas as pd
from pywinauto import Application, Desktop
from pywinauto.findwindows import ElementNotFoundError

# Determinar carpeta base donde buscar archivos externos.
# - Si la app está congelada por PyInstaller, usar el directorio del ejecutable.
# - Si se ejecuta como script, usar el dir del script.
# - Como alternativa también se puede usar el current working dir (donde se lanzó).

if getattr(sys, "frozen", False):
    # cuando PyInstaller crea un .exe, sys.executable apunta al ejecutable
    exe_dir = os.path.dirname(sys.executable)
    base_path = exe_dir
else:
    base_path = os.path.dirname(os.path.abspath(__file__))

# También permitir archivos en el working dir (opcional): se prioriza base_path.
def find_external_file(name):
    candidates = [
        os.path.join(base_path, name),
        os.path.join(os.getcwd(), name),
    ]
    for p in candidates:
        if os.path.exists(p):
            return p
    # devolver primera opción por defecto (para mensajes de error)
    return candidates[0]

# Leer contraseña
password_file = find_external_file("contrasena.txt")
if not os.path.exists(password_file):
    raise FileNotFoundError(f"No se encontró el archivo de contraseña. Se buscaron: {password_file}")

with open(password_file, "r", encoding="utf-8") as f:
    password = f.read().strip()

# Leer Excel y procesar dependencias
excel_file = find_external_file("expedientes.xlsx")
if not os.path.exists(excel_file):
    raise FileNotFoundError(f"No se encontró el archivo Excel: {excel_file}")

expedientes = pd.read_excel(excel_file, engine="openpyxl")

if "DEPENDENCIA" not in expedientes.columns:
    raise ValueError("El archivo Excel no contiene la columna 'DEPENDENCIA'")

def map_dependencia(val):
    val_str = str(val).zfill(4)
    if val_str.endswith("21") or val_str.endswith("021") or val_str.endswith("0021"):
        return "0021 I.R. Lima - PRICO"
    elif val_str.endswith("23") or val_str.endswith("023") or val_str.endswith("0023"):
        return "0023 I.R. Lima - MEPECO"
    else:
        return "DESCONOCIDO"

expedientes["DEPENDENCIA_COMPLETA"] = expedientes["DEPENDENCIA"].apply(map_dependencia)

orden_prioridad = {"0021 I.R. Lima - PRICO": 1, "0023 I.R. Lima - MEPECO": 2}
expedientes.sort_values(by="DEPENDENCIA_COMPLETA", key=lambda x: x.map(orden_prioridad), inplace=True)

dependencia_login = expedientes.iloc[0]["DEPENDENCIA_COMPLETA"]

# Ejecutar acceso directo o EXE
shortcut_path = os.path.join(base_path, "Actualiza RSIRAT.lnk")
if not os.path.exists(shortcut_path):
    shortcut_path = r"C:\\Program Files\\SIRAT\\SIRAT.exe"

if not os.path.exists(shortcut_path):
    raise FileNotFoundError(f"No se encontró el acceso directo ni el EXE: {shortcut_path}")

os.startfile(shortcut_path)

# Esperar y conectar a la ventana principal de forma robusta
def wait_and_connect_window(title="SIRAT", timeout=30, poll=0.5):
    desktop = Desktop(backend="uia")
    end_time = time.time() + timeout
    while time.time() < end_time:
        # 1) intento por título exacto
        try:
            win = desktop.window(title=title)
            if win.exists(timeout=1):
                handle = win.handle
                app = Application(backend="uia").connect(handle=handle)
                return app, app.window(handle=handle)
        except Exception:
            pass
        # 2) intento por regex (por si el título incluye más texto)
        try:
            win = desktop.window(title_re=f".*{title}.*")
            if win.exists(timeout=1):
                handle = win.handle
                app = Application(backend="uia").connect(handle=handle)
                return app, app.window(handle=handle)
        except Exception:
            pass
        time.sleep(poll)
    raise ElementNotFoundError({"title": title, "backend": "uia", "timeout": timeout})

# espera razonable para que la app arranque y la ventana aparezca
try:
    app, dlg = wait_and_connect_window("SIRAT", timeout=30)
except ElementNotFoundError as e:
    # listar ventanas detectadas para depuración si falla
    all_windows = Desktop(backend="uia").windows()
    titles = [w.window_text() for w in all_windows]
    raise RuntimeError(f"No se encontró la ventana 'SIRAT'. Ventanas detectadas: {titles}") from e

# Escribir dependencia
dependencia_edit = dlg.child_window(auto_id="1001", control_type="Edit")
dependencia_edit.type_keys(dependencia_login, with_spaces=True)

# Escribir contraseña
password_edit = dlg.child_window(auto_id="1005", control_type="Edit")
password_edit.type_keys(password, with_spaces=True)

# Click en Aceptar
dlg.child_window(title="Aceptar", control_type="Button").click()

print(f"Login completado con dependencia: {dependencia_login}")

# Esperar a que aparezca el menú
time.sleep(5)

# Buscar y hacer clic en "Cobranza Coactiva"
menu_item = dlg.child_window(title="Cobranza Coactiva", control_type="TreeItem")
menu_item.click_input()

print("Se hizo clic en 'Cobranza Coactiva'.")